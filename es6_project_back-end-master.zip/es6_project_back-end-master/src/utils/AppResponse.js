module.exports = (obj) => {
  return {
    status: "Success",
    data: obj,
  };
};
